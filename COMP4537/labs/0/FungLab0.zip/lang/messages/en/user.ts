export class User {
  static WIN_MESSAGE = "Excellent memory!";
  static LOSE_MESSAGE = "Wrong order!";
}
