export class User {
}
User.WIN_MESSAGE = "Excellent memory!";
User.LOSE_MESSAGE = "Wrong order!";
