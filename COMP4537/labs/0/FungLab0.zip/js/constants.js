export class Constants {
}
Constants.BUTTON_HEIGHT = "5em";
Constants.BUTTON_WIDTH = "10em";
// Offsets
Constants.STARTING_X_POSITION = 0;
Constants.VERTICAL_START = 75;
Constants.HORIZONTAL_START = 10;
// Time
Constants.SECOND = 1000;
Constants.TWO_SECONDS = 2000;
// Buttons
Constants.MAX_BUTTONS = 7;
// Offsets
Constants.OFFSET = 1;
// Colours
Constants.RGB_COLOURS_AMT = 256;
